package com.example.myapplicationbd;


import android.app.Activity;
        import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
        import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.List;

public class InsertLivroActivity extends AppCompatActivity {

    private EditText tituloEditText;
    private EditText generoEditText;
    private EditText anoEditText;
    private AutorAdapter adapter_autor;
    private Spinner autorSpinner;
    private List<Autor> listAutor;
    private DBHelper mydb;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_film);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        tituloEditText = (EditText) findViewById(R.id.tituloEditText);
        generoEditText = (EditText) findViewById(R.id.generoEditText);
        anoEditText = (EditText) findViewById(R.id.anoEditText);

        adapter_autor = new AutorAdapter();
        //spinner
        listAutor = adapter_autor.getListaAutores();
        autorSpinner = (Spinner) findViewById(R.id.autorSpinner);
        ArrayAdapter<Autor> spnAutorAdapter = new ArrayAdapter<Autor>(
                this,
                android.R.layout.simple_spinner_item,
                this.listAutor

        );
        this.autorSpinner.setAdapter(spnAutorAdapter);
    }


    public void Insert(View view){
        Livro livro = new Livro();
        livro.setTitulo(tituloEditText.getText().toString());
        livro.setGenero(generoEditText.getText().toString());
        livro.setAno(Integer.valueOf(anoEditText.getText().toString()));


        Intent returnIntent = new Intent();
        Bundle returnBundle = new Bundle();
        returnBundle.putParcelable("livro", livro);
        returnIntent.putExtras(returnBundle);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}