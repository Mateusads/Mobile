package com.example.myapplicationbd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String TAG = "DBHelper";

    //Colunas BD Autor
    public static final String  TABLE_AUTOR = "autores";
    public static final String  COLUMN_AUTOR_ID = "id";
    public static final String  COLUMN_AUTOR_NAME = "autor_name";
    public static final String  COLUMN_AUTOR_LIVRO_ID = "livro";

    //Colunas BD Livro

    public static final String  TABLE_LIVRO = "livros";
    public static final String  COLUMN_LIVRO_ID = "id";
    public static final String  COLUMN_LIVRO_TITULO = "titulo";
    public static final String  COLUMN_LIVRO_GENERO = "genero";
    public static final String  COLUMN_LIVRO_ANO = "ano";
    public static final String  COLUMN_LIVRO_AUTOR_ID = "autor_id";

    private static final String  DATABASE_NAME = "projetoDB.db";
    private static final int DATABASE_VERSION = 1;

    //sql CREATE LIVRO
    private static final String SQL_CREATE_TABLE_LIVROS = " CREATE TABLE " + TABLE_LIVRO + "("
            + COLUMN_LIVRO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_LIVRO_TITULO + " TEXT NOT NULL, "
            + COLUMN_LIVRO_GENERO + " TEXT NOT NULL, "
            + COLUMN_LIVRO_ANO + " INTEGER NOT NULL, "
            + COLUMN_LIVRO_AUTOR_ID + " INTEGER NOT NULL "
            + ");";

    //SQL CREATE AUTOR

    private static final String SQL_CREATE_TABLE_AUTORES = " CREATE TABLE " + TABLE_AUTOR + "("
            + COLUMN_AUTOR_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_AUTOR_NAME + " TEXT NOT NULL, "
            + COLUMN_AUTOR_LIVRO_ID + "INTEGER NOT NULL "
            +");";


    public DBHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database){
        database.execSQL(SQL_CREATE_TABLE_LIVROS);
        database.execSQL(SQL_CREATE_TABLE_AUTORES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        Log.w(TAG,

                "Upgrading the database from version" + oldVersion + " to " + newVersion);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_AUTOR);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LIVRO);

        //RECREATE
        onCreate(db);
    }

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);

    }




    public ArrayList<Livro> getAllLivros(){
        ArrayList<Livro> livros = new ArrayList<Livro>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+TABLE_LIVRO, null );
        res.moveToFirst();
        while(res.isAfterLast() == false){
            livros.add(new Livro(res.getInt(res.getColumnIndex(COLUMN_LIVRO_ID)),
                    res.getString(res.getColumnIndex(COLUMN_LIVRO_TITULO)),
                    res.getString(res.getColumnIndex(COLUMN_LIVRO_GENERO)),
                    res.getInt(res.getColumnIndex(COLUMN_LIVRO_ANO)),
                    res.getInt(res.getColumnIndex(COLUMN_LIVRO_AUTOR_ID))));
            res.moveToNext();
        }
        db.close();
        return livros;


    }



    public ArrayList<Autor> getAllAutores(){
        Log.d("debug", "erroGetAutores - 1");
        ArrayList<Autor> autores = new ArrayList<Autor>();
        SQLiteDatabase db = this.getReadableDatabase();
        Log.d("debug", "erroGetAutores - 2");
        Cursor res =  db.rawQuery( "select * from "+TABLE_AUTOR, null );
        res.moveToFirst();
        while(res.isAfterLast() == false){
            Log.d("debug", "erroGetAutores - 3");
            autores.add(new Autor(res.getInt(res.getColumnIndex(COLUMN_AUTOR_ID)),
                    res.getString(res.getColumnIndex(COLUMN_AUTOR_NAME)),
                    res.getInt(res.getColumnIndex(COLUMN_AUTOR_LIVRO_ID))));
            res.moveToNext();
        }
        Log.d("debug", "erroGetAutores - 4");
        db.close();
        return autores;
    }



    public Livro getLivro(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ TABLE_LIVRO +" where "
                + COLUMN_LIVRO_ID +"="+id+"", null );
        res.moveToFirst();
        Livro livro = new Livro(res.getInt(res.getColumnIndex(COLUMN_LIVRO_ID)),
                res.getString(res.getColumnIndex(COLUMN_LIVRO_TITULO)),
                res.getString(res.getColumnIndex(COLUMN_LIVRO_GENERO)),
                res.getInt(res.getColumnIndex(COLUMN_LIVRO_ANO)),
                res.getInt(res.getColumnIndex(COLUMN_LIVRO_AUTOR_ID)));
        db.close();
        return livro;
    }

    public long insertLivro(Livro livro){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_LIVRO_TITULO, livro.getTitulo());
        contentValues.put(COLUMN_LIVRO_GENERO, livro.getGenero());
        contentValues.put(COLUMN_LIVRO_ANO, livro.getAno());
        contentValues.put(COLUMN_LIVRO_AUTOR_ID, livro.getIdAutor());
        long i = db.insert(TABLE_LIVRO, null, contentValues);
        db.close();
        return i;
    }

    public long insertAutor(Autor autor){
        Log.d("debug", "erroInsertAutor - 1");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_LIVRO_TITULO, autor.getNome());
        contentValues.put(COLUMN_LIVRO_ANO, autor.getAno());
        Log.d("debug", "erroInsertAutor - 2");
        contentValues.put(COLUMN_LIVRO_AUTOR_ID, autor.getLivroEscrito());
        long i = db.insert(TABLE_AUTOR, null, contentValues);
        Log.d("debug", "erroInsertAutor - 2"+i);
        db.close();
        return i;
    }




}