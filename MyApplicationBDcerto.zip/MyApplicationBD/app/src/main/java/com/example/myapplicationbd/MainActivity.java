package com.example.myapplicationbd;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LivroAdapter adapter_livro;
    private AutorAdapter adapter_autor;
    private RecyclerView recyclerView;
    private DBHelper mydb;
    private List<Livro> arrayLivro;
    private List<String> listLivro;

    private static final int REQUEST_EDIT = 1;
    private static final int REQUEST_INSERT_LIVRO = 2;
    private static final int REQUEST_INSERT_AUTOR = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mydb = new DBHelper(this);

        adapter_livro = new LivroAdapter();
        recyclerView = (RecyclerView) findViewById(R.id.livrosRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        Log.d("debug", "erroTelaLivro- 1"+adapter_livro.getListaLivros());
        recyclerView.setAdapter(adapter_livro);

        adapter_autor = new AutorAdapter();
        Log.d("debug", "erroTelarecyclerView - 1");
        recyclerView = (RecyclerView) findViewById(R.id.autoresRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        Log.d("debug", "erroTelarecyclerView - 2"+adapter_autor.getListaAutores());
        recyclerView.setAdapter(adapter_autor);


        arrayLivro = adapter_livro.getListaLivros();
        final String[] listLivro = new String[arrayLivro.size()];

        int i = 0;
        for(Livro l: arrayLivro){
            listLivro[i] = l.toString();
            i++;
        }

    }



    public void inserirLivro(View view) {
        Log.d("debug", "erroTelaInserLivro - 1");
        Intent intent = new Intent(this, InsertLivroActivity.class);
        Bundle bundle = new Bundle();
        Log.d("debug", "erroTelaInserLivro - 2");
        bundle.putInt("request_code", REQUEST_INSERT_LIVRO);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_INSERT_LIVRO);
    }

    public void inserirAutor(View view) {

        Intent intent = new Intent(this, InsertAutorActivity2.class);
        Bundle bundle = new Bundle();
        bundle.putInt("request_code", REQUEST_INSERT_AUTOR);
        bundle.putParcelableArrayList("livrosArray", (ArrayList<? extends Parcelable>) arrayLivro);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_INSERT_AUTOR);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("debug", "erroTelaResult - 1");
        if (requestCode == REQUEST_INSERT_LIVRO) {
            Log.d("debug", "erroTelaResultLivro - 1");
            if (resultCode == Activity.RESULT_OK) {
                Livro l = data.getParcelableExtra("livro");
                mydb.insertLivro(l);
                adapter_livro.inserirLivro(l);
            }
        } if (requestCode == REQUEST_INSERT_AUTOR) {
            Log.d("debug", "erroTelaResultAutor - 1");
            if (resultCode == Activity.RESULT_OK) {
                Log.d("debug", "erroTelaResultAutor - 2");
                Autor a = data.getParcelableExtra("autor");
                mydb.insertAutor(a);
                adapter_autor.inserirAutor(a);

            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    public void maps(View view) {
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }

    public void CarregarLivro(View view) {
        adapter_livro.setListaLivros(mydb.getAllLivros());
    }

    public void CarregarAutor(View view) {
        Log.d("debug", "erroInsertAutor - 2");
        adapter_autor.setListaAutores(mydb.getAllAutores());
    }
}