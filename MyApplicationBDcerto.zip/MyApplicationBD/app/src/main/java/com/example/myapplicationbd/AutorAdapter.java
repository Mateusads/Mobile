package com.example.myapplicationbd;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AutorAdapter extends RecyclerView.Adapter {
    private List<Autor> listaAutores;

    public AutorAdapter(){
        listaAutores = new ArrayList<Autor>();
    }

    public List<Autor> getListaAutores() {
        return listaAutores;
    }

    public void setListaAutores(List<Autor> novaListaAutores) {
        while(getItemCount()>0)
            remover(0);

        for (Autor autor: novaListaAutores)
            inserirAutor(autor);

    }
    public void inserirAutor(Autor autor){
        Log.d("debug", "insertAutor - 1");
        listaAutores.add(autor);
        notifyItemInserted(getItemCount());
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.autor_row, viewGroup, false);
        AutorViewHolder holder = new AutorViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        AutorAdapter.AutorViewHolder holder = (AutorAdapter.AutorViewHolder) viewHolder;
        holder.nomeTextView.setText(listaAutores.get(i).getNome());
        holder.livroEscritoTextView.setText(listaAutores.get(i).getLivroEscrito());
        holder.anoTextView.setText(String.valueOf(listaAutores.get(i).getAno()));
    }

    @Override
    public int getItemCount() {
        return listaAutores.size();
    }



    public void update(Autor autor, int position){
        listaAutores.get(position).setNome(autor.getNome());
        listaAutores.get(position).setLivroEscrito(autor.getLivroEscrito());
        listaAutores.get(position).setAno(autor.getAno());
        notifyItemChanged(position);
    }

    public void remover(int position){
        listaAutores.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,this.getItemCount());
    }

    public static class AutorViewHolder extends RecyclerView.ViewHolder {

        TextView nomeTextView;
        TextView livroEscritoTextView;
        TextView anoTextView;

        public AutorViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setTag(this);
            nomeTextView = (TextView) itemView.findViewById(R.id.nomeTextView);
            livroEscritoTextView = (TextView) itemView.findViewById(R.id.livroEscritoTextView);
            anoTextView = (TextView) itemView.findViewById(R.id.anoTextView);
        }

    }

}
