package com.example.myapplicationbd;

import android.os.Parcel;
import android.os.Parcelable;

public class Livro implements Parcelable {

    private int idAutor;
    private String nomeAutor;
    private int id;
    private String titulo;
    private String genero;
    private int ano;

    public Livro(int id, String titulo, String genero, int ano, int idAutor) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.ano = ano;
        this.idAutor = idAutor;
    }

    public Livro(String titulo, String genero, int ano) {
        this.titulo = titulo;
        this.genero = genero;
        this.ano = ano;
    }

    public Livro() {

    }

    public Livro(Parcel in) {
        super();
        readFromParcel(in);
    }

    @Override
    public String toString(){
        return this.titulo;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAno() {
        return ano;
    }

    public int getIdAutor() {
        return idAutor;
    }

    public void setIdAutor(String nomeAutor) {
        this.nomeAutor = nomeAutor;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public Livro createFromParcel(Parcel in) {
        return new Livro(in);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(titulo);
        dest.writeString(genero);
        dest.writeInt(ano);
        dest.writeInt(idAutor);
    }

    public void readFromParcel(Parcel parcel){
        this.id = parcel.readInt();
        this.titulo = parcel.readString();
        this.genero = parcel.readString();
        this.ano = parcel.readInt();
        this.idAutor = parcel.readInt();

    }

    public static final Parcelable.Creator<Livro> CREATOR = new Parcelable.Creator<Livro>(){
        @Override
        public Livro createFromParcel (Parcel p){
            Livro livro = new Livro();
            livro.readFromParcel(p);
            return livro;
        }
        @Override
        public Livro[] newArray(int size){
            return new Livro[size];
        }
    };

}
