package com.example.myapplicationbd;

import android.os.Parcel;
import android.os.Parcelable;

public class Autor  implements Parcelable{


    private int id;
    private String nome;
    private String livroEscrito;
    private int ano;
    private int livroID;


    public Autor(int anInt, String nome, int ano) {
    }
    public Autor(int anInt, String string, int anInt1, int anInt2) {
    }
    public Autor() {
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String titulo) {
        this.nome = titulo;
    }

    public String getLivroEscrito() {
        return livroEscrito;
    }

    public void setLivroEscrito(String livroEscrito) {
        this.livroEscrito = livroEscrito;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(nome);
        dest.writeInt(ano);
        dest.writeInt(livroID);
    }

    public void readFromParcel(Parcel parcel){
        this.id = parcel.readInt();
        this.nome = parcel.readString();
        this.ano = parcel.readInt();
        this.livroID = parcel.readInt();
    }

    public static final Parcelable.Creator<Autor> CREATOR = new Parcelable.Creator<Autor>(){
        @Override
        public Autor createFromParcel (Parcel p){
            Autor autor = new Autor();
            autor.readFromParcel(p);
            return autor;
        }
        @Override
        public Autor[] newArray(int size){
            return new Autor[size];
        }
    };
}
