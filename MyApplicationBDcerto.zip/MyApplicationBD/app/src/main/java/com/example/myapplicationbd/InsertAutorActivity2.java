package com.example.myapplicationbd;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class InsertAutorActivity2 extends AppCompatActivity {

    private EditText nomeEditText;
    private EditText livroEscritoEditText;
    private EditText anoEditText;
    private TextView dados;
    private LivroAdapter adapter_livro;
    private Spinner livroSpiner;
    private ArrayList<Livro> arrayLivro;
    private DBHelper mydb;
    private Spinner sp;
    private String livroStringSpinner = null;
    private Bundle b = null;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_autor2);
        Log.d("debug", "insertAutor - 1");
        nomeEditText = (EditText) findViewById(R.id.nomeEditText);
        livroEscritoEditText = (EditText) findViewById(R.id.livroEscritoEditText);
        anoEditText = (EditText) findViewById(R.id.anoEditText);
        adapter_livro = new LivroAdapter();
        Log.d("debug", "insertAutor - 2");
        dados = (TextView) findViewById(R.id.DadosTextView);



        Bundle extras = getIntent().getExtras();
        assert extras != null;
        ArrayList<Livro> arrayLivro  = extras.getParcelableArrayList("livrosArray");

        Livro livro1 = arrayLivro.get(0);


        String s = livro1.toString();

        livroStringSpinner = s;


        final String[] listLivro = new String[]{
                livroStringSpinner, "teste", "teste1"
        };
        Log.d("debug", "insertAutorArrayLivro - 1");



        Log.d("debug", "insertAutor - 5");



        //spinner statico
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                listLivro
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        sp = (Spinner) findViewById(R.id.livroSpiner);
        sp.setAdapter(adapter);


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String dados1 = listLivro[position];
                dados.setText(dados1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        //spinner
        Log.d("debug", "erroTelaAutor - 3");
//        livroList = adapter_livro.getListaLivros();
//        livroSpiner = (Spinner) findViewById(R.id.livroSpiner);
//        ArrayAdapter<Livro> spnLivroAdapter = new ArrayAdapter<Livro>(
//                this,
//                android.R.layout.simple_spinner_item,
//                this.livroList
//
//        );
//        this.livroSpiner.setAdapter(spnLivroAdapter);
//    }
    }


    public void InsertAutor(View view) {
        Autor autor = new Autor();

        autor.setNome(nomeEditText.getText().toString());
        autor.setAno(Integer.valueOf(anoEditText.getText().toString()));

        Intent returnIntent = new Intent();
        Bundle returnBundle = new Bundle();
        returnBundle.putParcelable("autor", autor);
        returnIntent.putExtras(returnBundle);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}
