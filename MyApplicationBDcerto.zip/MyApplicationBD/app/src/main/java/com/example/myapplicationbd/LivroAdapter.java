package com.example.myapplicationbd;


import android.support.annotation.NonNull;
        import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
import android.widget.TextView;

        import java.util.ArrayList;
        import java.util.List;

public class LivroAdapter extends RecyclerView.Adapter {

    private List<Livro> listaLivros;

    public LivroAdapter(){
        listaLivros = new ArrayList<Livro>();
    }

    public List<Livro> getListaLivros() {
        return listaLivros;
    }

    public void setListaLivros(List<Livro> novaListaFilmes) {
        while(getItemCount()>0)
            remover(0);

        for (Livro livro: novaListaFilmes)
            inserirLivro(livro);

    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.filme_row, viewGroup, false);
        LivroViewHolder holder = new LivroViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        LivroViewHolder holder = (LivroViewHolder) viewHolder;
        holder.tituloTextView.setText(listaLivros.get(i).getTitulo());
        holder.generoTextView.setText(listaLivros.get(i).getGenero());
        holder.anoTextView.setText(String.valueOf(listaLivros.get(i).getAno()));
    }

    @Override
    public int getItemCount() {
        return listaLivros.size();
    }

    public void inserirLivro(Livro livro){
        listaLivros.add(livro);
        notifyItemInserted(getItemCount());
    }


    public void update(Livro livro, int position){
        listaLivros.get(position).setTitulo(livro.getTitulo());
        listaLivros.get(position).setGenero(livro.getGenero());
        listaLivros.get(position).setAno(livro.getAno());
        notifyItemChanged(position);
    }

    public void remover(int position){
        listaLivros.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,this.getItemCount());
    }

    public static class LivroViewHolder extends RecyclerView.ViewHolder {

        TextView tituloTextView;
        TextView generoTextView;
        TextView anoTextView;

        public LivroViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setTag(this);
            tituloTextView = (TextView) itemView.findViewById(R.id.tituloTextView);
            generoTextView = (TextView) itemView.findViewById(R.id.generoTextView);
            anoTextView = (TextView) itemView.findViewById(R.id.anoTextView);
        }

    }
}